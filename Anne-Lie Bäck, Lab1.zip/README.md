# myFirstAdventure
My very first text based adventure in Javascript.

This is the story about your quest through the woods. Will you manage to take the lunch to grandma and will you manage to save some lifes through the process?

There's many loops and holes and almost all the user's choices affects the story's progress and the ending of the story. An exciting adventure that was hell to bugtest.
Enjoy!

I came to the conclusion that I should've made objects out of some of the variables, like the witch and the wolf, but there was no time
to change everything that needed to be changed before deadline. I will keep it in mind for next timeI do a project, and I'll probably fix it in this one as an after-assignment thing just for the purpose of learning how to fix it and have a fixed version on gitHub.

I also wish to fix the capability of hitting enter instead of using the button, and emptying the input-field between inputs. But I chose to not incorporate these features in this version, but hopefully they will exist in version 2.0.

Repo: https://github.com/Anne-Lie-Back/myFirstAdventure
Demo: https://anne-lie-back.github.io/myFirstAdventure/
